/*
 * Copyright (c) 2018 Ellis Michael (emichael@cs.washington.edu)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package dslabs.framework.testing;

import dslabs.framework.Address;
import dslabs.framework.Timer;
import dslabs.framework.VizIgnore;
import java.time.Duration;
import java.util.Random;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NonNull;

/**
 * Stores a timer, its delivery address, its duration, and its creation time. Equality is based on
 * delivery address, timer object, and duration only.
 *
 * <p>Note: this class has a natural ordering that is inconsistent with equals.
 */
@Data
@EqualsAndHashCode(of = {"to", "timer", "minTimerLengthMillis", "maxTimerLengthMillis"})
public final class TimerEnvelope implements Event, Comparable<TimerEnvelope> {
  private static final Random rand = new Random();

  private final Address to;
  private final Timer timer;

  @VizIgnore
  private final long minTimerLengthMillis, maxTimerLengthMillis, timerLengthMillis, startTimeNanos;

  public TimerEnvelope(
      Address to, Timer timer, long minTimerLengthMillis, long maxTimerLengthMillis) {
    this.to = to;
    this.timer = timer;
    this.minTimerLengthMillis = minTimerLengthMillis;
    this.maxTimerLengthMillis = maxTimerLengthMillis;

    if (minTimerLengthMillis > maxTimerLengthMillis) {
      throw new IllegalArgumentException("Minimum timer length greater than maximum timer length");
    }

    if (minTimerLengthMillis == maxTimerLengthMillis) {
      this.timerLengthMillis = minTimerLengthMillis;
    } else {
      this.timerLengthMillis =
          minTimerLengthMillis + rand.nextLong(1 + maxTimerLengthMillis - minTimerLengthMillis);
    }

    this.startTimeNanos = System.nanoTime();
  }

  public TimerEnvelope(Address to, Timer timer, Duration minTimerLength, Duration maxTimerLength) {
    this(to, timer, minTimerLength.toMillis(), maxTimerLength.toMillis());
    // TODO: Make this the canonical constructor, store Duration/Instant in TimerEnvelope.
  }

  @Override
  public Address locationRootAddress() {
    return to.rootAddress();
  }

  public long endTimeNanos() {
    return startTimeNanos + (timerLengthMillis() * 1000000);
  }

  public long timeRemainingNanos() {
    return endTimeNanos() - System.nanoTime();
  }

  public boolean isDue() {
    return timeRemainingNanos() <= 0;
  }

  @Override
  public int compareTo(@NonNull TimerEnvelope o) {
    return Long.compare(endTimeNanos(), o.endTimeNanos());
  }

  @Override
  public String toString() {
    return String.format("Timer(-> %s, %s)", to, timer);
  }
}
